user_text=""" 
Clearing the decks for a landmark legislation on 33% reservation for women in Lok Sabha and state Assemblies, the Lower House Wednesday passed the women’s reservation Bill – the Constitution (One Hundred and Twenty-Sixth Amendment) Bill, 2023 – with Union Home Minister Amit Shah declaring that “the empowerment of women is a matter of principle, not a political weapon” for “our leader Prime Minister Narendra Modi and the party”.

Wrapping up a discussion on the Bill introduced Tuesday in Lok Sabha, Shah, in his reply, assured the House of a “transparent process” to identify the seats to be reserved for women.

Responding to apprehensions of delay in the Bill’s implementation, Shah said the next government will conduct the census and the delimitation exercise immediately after the elections and set in motion the process to make reservation for women in Lok Sabha and state Assemblies a reality.

Also in Political Pulse | Sonia Gandhi leads Oppn chorus: Implement immediately, extend benefit to OBCs
Describing the Bill, which will be taken to Rajya Sabha Thursday for its clearance, as a “good start”, Shah said “anything incomplete” could be addressed in the future.

On Opposition demands that the proposed legislation should include a quota for the OBCs, the Home Minister said Parliamentarians are currently elected in three categories – General, Scheduled Caste and Scheduled Tribe – and the Bill has incorporated a quota for each of them.


He said the “delimitation process” to decide which constituency is to be reserved for women will be “transparent” and it will be done by a delimitation commission. “If we do it and Wayanad (Lok Sabha constituency of Congress leader Rahul Gandhi) gets reserved, it would be an issue for you,” he said.

He said the delimitation commission would be headed by a retired Supreme Court judge, a representative of the Election Commission and a member each from the political parties. The committee, he said, will take its decisions after visits to the constituencies to ensure the process is fair and transparent.

Must Read | Calling himself ‘chosen one’, PM Modi brings in women’s Bill, with SC/ST quota
Hitting back at the Opposition which criticised the government for using the long-pending women’s Bill as a political tool on the eve of elections, he said: “For our leader Prime Minister Narendra Modi and the party, the empowerment of women is a matter of principle, not a political weapon… Women’s security, respect and equal participation have been the life force of the government since Prime Minister Modi took oath of office.”

Without referring to Rahul Gandhi’s remark that there are only three OBC Secretaries in the Government of India, Shah said, “Some people think secretaries run the country, I think the government does. This government run by the BJP has 85 OBC MPs which is 29% of the total number of party MPs. Of the party’s 1318 legislators across India, 365, which constitutes 27 %, are OBC MLAs. Around 40% of the BJP MLCs are OBCs… Congress never made an OBC as the Prime Minister, but the BJP has.”

During the debate, ruling party speakers slammed the Opposition, saying their government in the past brought Bills without the intention to get it cleared and pushed them as “lollipops or token” to “eyewash the voters.”

The ruling party MPs also said that the provisions of the Constitution regarding census and delimitation had to be included in the Bill to follow the Constitution.

In Premium | Before women’s quota, first Census, then delimitation
“The Prime Minister has repeatedly said ‘yahi samay hai, sahi samay hai’ (this is the time, this is the right time), and this Bill has been brought at the right time. What bothers the Opposition is that it is now brought by Prime Minister Modi and the BJP,” Nishikant Dubey, who initiated the debate from the ruling party side, said.

Targeting the Congress which tried to bring the Bill during UPA rule, Dubey said it developed cold feet and had “excuses” like consensus and quota-within-quota.

Both Dubey and Union Minister Smriti Irani took on the Opposition over the demand for immediate implementation of the Bill, saying the government was just following the Constitutional process.


Reading out provisions of the Constitution regarding census and delimitation to drive home the point that it was necessary to include these in the Bill, Irani asked: “Is it the wish of Opposition leaders that the Constitutional process is not followed? Should we not abide by the Constitution? Is that the position taken by the Opposition parties?”

As Opposition MPs raised questions on the census delay, Dubey cited the Covid pandemic and the lockdown that followed as the reasons. “How could we do the census during the pandemic? … Our Home Minister Amit Shah keeps saying that no steps would be taken by this government that is not in accordance with the provisions of the Constitution,” he said.

Also Read | Census, delimitation process not required for women’s quota Bill, should be implemented now: Rahul Gandhi
Irani, who described the Bill as Goddess Laxmi taking a Constitutional form, said the BJP, right from its Jana Sangh days, stood for constitutionally-guaranteed reservation for women.

Taking on the Congress which maintained that the Bill was its agenda, Irani said: “Success has many fathers and failure has none. So when the Bill was introduced yesterday, some people started saying that it was their Bill… But I am glad that someone here has clarified that even the 73rd and the 75th Constitutional amendments (related to Panchayati Raj and Rent Tribunals), which were said to have been brought by a certain political family, were also by P V Narasimha Rao.”

“This government guarantees reservation for 15 years. Congress proposed a reservation for only 10 years. They wanted to snatch the rights of women after 10 years. Article 82 of the Constitution talks about delimitation after the census in 2026. Is it the position of the Opposition leaders that we should not abide by the Constitution?” Irani said.

MOST READ
1
As Indo-Canadian relations sour, anxiety grips Indian students, residents who wish to settle in Canada
2
Jawan box office collection day 13: Shah Rukh Khan film to pass Rs 900 crore globally, just days away from overtaking Pathaan
See More
Women's quota Bill | From Sonia Gandhi, Kanimozhi to Smriti Irani – here’s what lawmakers said
She also hit out at the Opposition, such as the Samajwadi Party, for demanding reservation for minorities, saying they do not know that reservation based on religion is “prohibited” by the Constitution. “Those who are arguing this perhaps do not know that reservation on the basis of religion is prohibited in the Constitution. The nation supports this Bill. If the Opposition does not become a roadblock to this, we will be grateful.”

She said Prime Minister Modi had always focused on women’s empowerment through gender equity policy and gender budget. The gender budget under UPA in 2013-14 was Rs 90,000 crore. Under the Modi government, the gender budget in 2023-24 is Rs 2.23 lakh crore, she said.

ALSO READ
india canada ties, hardeep singh nijjar, justin trudeau, bjp, congress, akali dal, khalistan
India-Canada diplomatic row: BJP and Congress slam Justin Trudeau, Akalis...
nitish
Chill in Nitish, INDIA ties grows: Boycott of TV anchors to coordination ...
Karnataka Siddaramaiah Shivakumar
Siddaramaiah-Shivakumar rivalry continues to simmer in Karnataka as proxi...
Womens reservation bill
Calling himself ‘chosen one’, PM Modi brings in women’s Bill, with SC/ST ...
Sunita Duggal of the BJP called the women’s reservation Bill “historic”, and said women of the country know that it is only Prime Minister Modi who can grant them 33 per cent reservation. She appealed to MPs across political parties to support the Bill.
"""

from transformers import BartTokenizer, BartForConditionalGeneration, BartConfig

model = BartForConditionalGeneration.from_pretrained('sshleifer/distilbart-cnn-12-6')
tokenizer = BartTokenizer.from_pretrained('sshleifer/distilbart-cnn-12-6')

inputs = tokenizer(user_text, truncation=True, return_tensors='pt')

# Generate Summary
summary_ids = model.generate(inputs['input_ids'], num_beams=4, early_stopping=True, min_length=1000, max_length=000)
summarized_text = ([tokenizer.decode(g, skip_special_tokens=True, clean_up_tokenization_spaces=True) for g in summary_ids])
print(summarized_text[0])