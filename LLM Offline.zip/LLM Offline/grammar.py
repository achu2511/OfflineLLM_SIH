import language_tool_python

# Initialize LanguageTool
tool = language_tool_python.LanguageTool('en-US')  # Replace 'en-US' with the language you want to check

# Text to be checked
text = """Me and my friend ain't never been to the big city before. We was so excited when we arrived, but we quickly realize that we ain't prepare for the hustle and bustle. The traffic was crazy, and we didn't knew where to go. We was lost in the midst of all them tall buildings.

After a while, we decide to ask for directions from a kind stranger. They was really helpful and told us how to get to the main square. We was so grateful for their help. We walk for what seemed like forever, and finally we reach the square. It was so crowded, but we was happy to be there.

We decide to have lunch at a fancy restaurant nearby. The menu was so fancy, we didn't knew what to order. The waiter was really patient with us and recommend the special of the day. It was a delicious meal, and we was really enjoy it.

Later, we went to visit a famous museum. The art was so beautiful, we was in awe. We didn't understood all of it, but we appreciate the talent. We spent hours there, admiring the paintings and sculptures.

As the day was coming to a close, we realize that we didn't knew how to get back to our hotel. We was feeling a little worried, but then we remember the directions the kind stranger gave us. We follow them and eventually find our way back.

That night, we was exhausted but happy. We never forget our first trip to the big city. It was an adventure we will always cherish."""

# Check for grammar errors
matches = tool.check(text)

# Print the grammar errors
for match in matches:
    print(match)

# Correct the text
corrected_text = tool.correct(text)
print(corrected_text)